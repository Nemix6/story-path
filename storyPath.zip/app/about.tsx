import { View, Text } from "react-native"

const About = () => {

    return (
        <View>
            <Text>About</Text>
        </View>
    )
}

export default About;