import { View, Text } from "react-native"

const Scanner = () => {
    return (
        <View>
            <Text>Scanner</Text>
        </View>
    );
}

export default Scanner;