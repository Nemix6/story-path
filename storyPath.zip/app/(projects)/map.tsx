import { View, Text } from "react-native";

const Map = () => {
    return (
        <View>
            <Text>Map</Text>
        </View>
    );
};
export default Map;