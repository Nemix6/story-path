import { View, Text, StyleSheet } from "react-native"
import { useLocalSearchParams } from "expo-router";
import { useEffect, useState } from "react";
import { getProject, getLocations } from "@/api/api";
import { ProjectProps } from "../projectLists";

// an interface to define the structure of a location.
export interface Location {
    location_name: string;
    location_trigger: string;
    location_position: string;
    score_points: number;
    clue: string;
    location_content: string;
    location_order: number;
    id: number;
}

const Project = () => {
    const { project_id} : {project_id : string} = useLocalSearchParams();
    const [project, setProject] = useState<ProjectProps>();
    const [points, setPoints] = useState<number>(0);
    const [totalPoints, setTotalPoints] = useState<number>(0);
    const [locationsVisited, setLocationsVisited] = useState<number>(0);
    const [locations, setLocations] = useState<Location[]>([]);

    useEffect(() => {
        const fetchProject = async () => {
            const project = await getProject(project_id) as ProjectProps;
            setProject(project);

            const locations = await getLocations(project_id) as Location[];
            let orderedLocations = locations.slice().sort((a: Location, b: Location) => a.location_order - b.location_order);
            setLocations(orderedLocations);
            setTotalPoints(orderedLocations.reduce((acc: number, loc: Location) => acc + loc.score_points, 0));

        };
        fetchProject();
    }, [project_id]);

    

    return (
        <View>
            {/* Make the header banner */}
            <View style={styles.header_container}>
                <View style={styles.text_container}>
                    <Text style={styles.header_text}>{project?.title}</Text>
                </View>
            </View>
            {/* GAME CONTAINER */}
            {locations.length == 0 ? <Text style={styles.error_text}>This project has no locations :(</Text> :
            <View style={styles.game_container}>
                <Text style={styles.header2_text}>Instructions</Text>
                <Text style={styles.text}>{project?.instructions}</Text>
                <Text style={styles.header2_text}>Initial Clue</Text>
                <Text style={styles.text}>{project?.initial_clue}</Text>

                <View style={styles.scores_container}>
                    <View style={styles.button_container}>
                        <Text style={styles.button_text}>Points</Text>
                        <Text style={styles.button_text}>{points} / {totalPoints}</Text>
                    </View>
                    <View style={styles.button_container}>
                        <Text style={styles.button_text}>Locations Visited</Text>
                        <Text style={styles.button_text}>{locationsVisited} / {locations.length}</Text>
                    </View>
                </View>
            </View>
            }
        </View>
        
    )
}

export default Project;


const styles = StyleSheet.create({
    header_container: {
        backgroundColor: "#fc6f03",
        height: 100,
        justifyContent: "center",
    },

    text_container: {
        marginHorizontal: 20,
        paddingHorizontal: 20,
        alignItems: "center",
    },

    game_container: {
        // controls the distance of container to the edge of the screen
        marginHorizontal: 10,
        // controls the distance of text to the edge of the container
        paddingHorizontal: 25,
        marginTop: 20,
        backgroundColor: "white",
        borderRadius: 10,
        borderWidth: 1,
        borderColor: "#afbab2",
    },

    header_text: {
        fontSize: 36,
        fontWeight: "bold",
        color: "white",
    },

    header2_text: {
        fontSize: 24,
        fontWeight: "bold",
        marginTop: 20,  
    },

    error_text: {
        fontSize: 24,
        fontWeight: "bold",
        marginTop: 20,  
        color: "red",
        paddingHorizontal: 20,
    },

    text : {
        marginTop: 5,
    },

    scores_container: {
        marginTop: 20,
        paddingBottom: 20,
        borderBottomWidth: 1,
        borderBottomColor: "#afbab2",
        flexDirection: "row",
        justifyContent: "space-between",
    },

    button_container : {
        backgroundColor: "#fc6f03",
        borderRadius: 10,
        alignItems: "center",
        width: 150,
        paddingVertical: 10,

    },

    button_text : {
        fontSize: 15,
        fontWeight: "bold",
        color: "white",
        paddingVertical: 5,
        
    },
});

