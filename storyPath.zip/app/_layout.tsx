import { router, usePathname } from "expo-router"
import React, { useEffect } from "react"
import { DrawerContentScrollView } from '@react-navigation/drawer'
import { View, StyleSheet, Text } from "react-native"
import CustomDrawerItem from "@/components/customDrawerItem"
import { Drawer } from "expo-router/drawer"
import Icon from 'react-native-vector-icons/Feather';
import { FontAwesome5 } from "@expo/vector-icons"
import { UserProvider } from "@/components/UserContext"
import { useUser } from "@/components/UserContext"

const CustomDrawerContent = (props: any) => {
    const path_name = usePathname()
    const { username } = useUser()

    useEffect(() => {
        console.log(path_name)
    }, [path_name]);

    return (
        // wraps the drawer content and allows it to be scrollable. It also passes the props to the drawer content
       <DrawerContentScrollView {...props}>
            <View style={styles.infoContainer}>
                <View style={styles.infoDetailsContainer}>
                    <FontAwesome5 name="book-reader" size={40} color="#fc6f03" style={styles.icon} />
                    <Text style={styles.appTitle}>StoryPath</Text>
                </View>
            </View>

            <View style={styles.infoContainer}>
                <Icon name="user" size={30} color="#000" />
                <View style={styles.userDetailsContainer}>
                    <Text style={styles.appText}>Current User:</Text>
                    <Text style={styles.appText}>{username || "No User"}</Text>
                </View>
            </View>
            
            <CustomDrawerItem label="Welcome" icon={"home"} path_name={path_name} route_path="/" is_active={path_name === "/"} />
            <CustomDrawerItem label="Profile" icon={"user"} path_name={path_name} route_path="/profile" is_active={path_name === "/profile"} />
            <CustomDrawerItem label="Projects" icon={"briefcase"} path_name={path_name} route_path="/projectLists" is_active={path_name === "/projectLists"} />
            <CustomDrawerItem label="About" icon={"info"} path_name={path_name} route_path="/about" is_active={path_name === "/about"} />

       </DrawerContentScrollView>
    );
}

export default function Layout() {
    return (
        <UserProvider>
            <Drawer drawerContent={(props: any) => <CustomDrawerContent {...props} />} screenOptions={{headerShown: false}}>
                <Drawer.Screen name="index" options={{headerShown: true, headerTitle: "Home"}} />
                <Drawer.Screen name="profile" options={{headerShown: true, headerTitle: "Profile"}} />
                <Drawer.Screen name="projectLists" options={{headerShown: true, headerTitle: "Projects"}} />
                <Drawer.Screen name="about" options={{headerShown: true, headerTitle: "About"}} />
            </Drawer>
        </UserProvider>
    );
}


const styles = StyleSheet.create({

    infoContainer: {
        flexDirection: "row", // aligns items horizontally
      paddingHorizontal: 10,
      paddingVertical: 20,
      borderBottomColor: "#ccc",
      borderBottomWidth: 1,
      marginBottom: 0,
      alignItems: "center", // aligns items vertically
    },
    infoDetailsContainer: {
      marginTop: 25,
      marginLeft: 10,
        flexDirection: "row",
    },
    appTitle: {
      fontSize: 32,
      fontWeight: 'bold',
      color: "#fc6f03",
    },

    userDetailsContainer: {
        marginTop: 1,
        marginLeft: 10,
    },

    appText: {
        fontSize: 18,
        },

    icon: {
        marginRight: 14,
    },
  });
  