/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string = string> extends Record<string, unknown> {
      StaticRoutes: `/` | `/(projects)` | `/(projects)/map` | `/(projects)/scanner` | `/_sitemap` | `/about` | `/map` | `/profile` | `/projectLists` | `/scanner`;
      DynamicRoutes: `/${Router.SingleRoutePart<T>}` | `/(projects)/${Router.SingleRoutePart<T>}`;
      DynamicRouteTemplate: `/(projects)/[project_id]` | `/[project_id]`;
    }
  }
}
