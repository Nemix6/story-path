import React, { createContext, useState, useContext } from 'react';

const UserContext = createContext({
    username: "no user",
    setUsername: (username: string) => {}
});

export const UserProvider = (props : any) => {
    const [username, setUsername] = useState("no user");

    return (
        <UserContext.Provider value={{ username, setUsername }}>
            {props.children}
        </UserContext.Provider>
    );
}

export const useUser = () => useContext(UserContext);